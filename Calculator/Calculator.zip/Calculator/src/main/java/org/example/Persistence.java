package org.example;

public class Persistence {
    public static EntityManagerFactory createEntityManagerFactory(String s) {
        return null;
    }
}
