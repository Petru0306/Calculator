//package org.example;
//
//import junit.framework.TestCase;
//import org.junit.Test;
//
//import static junit.framework.TestCase.assertEquals;
//
//public class JavaTest {
//    @Test
//    public void twoPlusTwoShouldEqualFour() {
//        var calculator = new Calculator();
//        Operation addition = new Addition();
//        assertEquals(4.0, calculator.executeOperation(addition, 2, 2));
//    }
//    @Test
//    public void twoMultipliedBythreeShouldEqualSix() {
//        var calculator = new Calculator();
//        Operation multiplication = new Multiplication();
//        assertEquals(6.0, calculator.executeOperation(multiplication, 2, 3));
//    }
//
//}
