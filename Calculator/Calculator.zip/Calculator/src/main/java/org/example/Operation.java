package org.example;

public interface Operation {
    double calculate(double a, double b);
}
