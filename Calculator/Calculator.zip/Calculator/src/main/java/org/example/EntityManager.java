package org.example;

public class EntityManager {
}
