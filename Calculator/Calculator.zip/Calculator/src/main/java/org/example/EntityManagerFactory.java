package org.example;

public interface EntityManagerFactory {
}
