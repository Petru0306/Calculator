package org.example;

public abstract class OperationFactory {
    protected abstract Operation createOperation();
}
