package org.hibernate.jpa;
public class HibernatePersistenceProvider  {

}
